﻿namespace PHqctx
{
    partial class User_RegisteredPeopleModuleRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.label23 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.label24 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.label31 = new System.Windows.Forms.Label();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI Symbol", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(11, 9);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(374, 50);
            this.label6.TabIndex = 7;
            this.label6.Text = "APPLICATION FORM";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(197, 74);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(36, 25);
            this.textBox1.TabIndex = 8;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(234, 58);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(73, 25);
            this.textBox2.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label1.Location = new System.Drawing.Point(4, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "REFERENCE NUMBER:";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(240, 74);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(49, 25);
            this.textBox3.TabIndex = 11;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(293, 74);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(49, 25);
            this.textBox4.TabIndex = 12;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(347, 74);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(49, 25);
            this.textBox5.TabIndex = 13;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(401, 74);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(88, 25);
            this.textBox6.TabIndex = 14;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(494, 74);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(143, 25);
            this.textBox7.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label2.Location = new System.Drawing.Point(4, 60);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(230, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "UNIQUE LEARNERS IDENTIFIER (ULI):";
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(323, 59);
            this.textBox8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(62, 25);
            this.textBox8.TabIndex = 17;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(403, 59);
            this.textBox9.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(73, 25);
            this.textBox9.TabIndex = 18;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(495, 59);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(93, 25);
            this.textBox10.TabIndex = 19;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(603, 59);
            this.textBox11.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(73, 25);
            this.textBox11.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label3.Location = new System.Drawing.Point(307, 60);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 20);
            this.label3.TabIndex = 21;
            this.label3.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label4.Location = new System.Drawing.Point(388, 62);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 20);
            this.label4.TabIndex = 22;
            this.label4.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label5.Location = new System.Drawing.Point(479, 62);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 20);
            this.label5.TabIndex = 23;
            this.label5.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label7.Location = new System.Drawing.Point(591, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 20);
            this.label7.TabIndex = 24;
            this.label7.Text = "-";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton5);
            this.panel1.Controls.Add(this.radioButton4);
            this.panel1.Controls.Add(this.radioButton3);
            this.panel1.Controls.Add(this.radioButton2);
            this.panel1.Controls.Add(this.radioButton1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(50, 160);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(680, 50);
            this.panel1.TabIndex = 25;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.BackColor = System.Drawing.Color.Transparent;
            this.radioButton5.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton5.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButton5.Location = new System.Drawing.Point(581, 23);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(56, 24);
            this.radioButton5.TabIndex = 31;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "OWF";
            this.radioButton5.UseVisualStyleBackColor = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.BackColor = System.Drawing.Color.Transparent;
            this.radioButton4.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton4.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButton4.Location = new System.Drawing.Point(520, 23);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(53, 24);
            this.radioButton4.TabIndex = 30;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "K-12";
            this.radioButton4.UseVisualStyleBackColor = false;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.BackColor = System.Drawing.Color.Transparent;
            this.radioButton3.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton3.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButton3.Location = new System.Drawing.Point(364, 23);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(148, 24);
            this.radioButton3.TabIndex = 29;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "INDUSTRY WORKER";
            this.radioButton3.UseVisualStyleBackColor = false;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackColor = System.Drawing.Color.Transparent;
            this.radioButton2.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton2.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButton2.Location = new System.Drawing.Point(225, 23);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(131, 24);
            this.radioButton2.TabIndex = 28;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "TVET GRADUATE";
            this.radioButton2.UseVisualStyleBackColor = false;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.Color.Transparent;
            this.radioButton1.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton1.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButton1.Location = new System.Drawing.Point(8, 23);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(209, 24);
            this.radioButton1.TabIndex = 27;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "TVET GRADUATING STUDENT";
            this.radioButton1.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(4, 2);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 20);
            this.label8.TabIndex = 26;
            this.label8.Text = "CLIENT TYPE:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox14);
            this.panel2.Controls.Add(this.textBox13);
            this.panel2.Controls.Add(this.textBox12);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(50, 216);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(680, 129);
            this.panel2.TabIndex = 26;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(96, 92);
            this.textBox14.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(541, 25);
            this.textBox14.TabIndex = 36;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(96, 60);
            this.textBox13.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(541, 25);
            this.textBox13.TabIndex = 35;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(96, 26);
            this.textBox12.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(541, 25);
            this.textBox12.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label12.Location = new System.Drawing.Point(29, 97);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 20);
            this.label12.TabIndex = 34;
            this.label12.Text = "MIDDLE:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label11.Location = new System.Drawing.Point(4, 65);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 20);
            this.label11.TabIndex = 33;
            this.label11.Text = "FIRSTNAME:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label10.Location = new System.Drawing.Point(15, 31);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 20);
            this.label10.TabIndex = 27;
            this.label10.Text = "SURNAME:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label9.Location = new System.Drawing.Point(4, 1);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 20);
            this.label9.TabIndex = 32;
            this.label9.Text = "PROFILE:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.textBox21);
            this.panel3.Controls.Add(this.textBox20);
            this.panel3.Controls.Add(this.textBox19);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.textBox18);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.textBox17);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.textBox16);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.textBox15);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Location = new System.Drawing.Point(50, 352);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(680, 129);
            this.panel3.TabIndex = 27;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label20.Location = new System.Drawing.Point(540, 103);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 20);
            this.label20.TabIndex = 49;
            this.label20.Text = "ZIP CODE";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label19.Location = new System.Drawing.Point(386, 103);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 20);
            this.label19.TabIndex = 48;
            this.label19.Text = "REGION";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label18.Location = new System.Drawing.Point(211, 103);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 20);
            this.label18.TabIndex = 47;
            this.label18.Text = "PROVINCE";
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(500, 75);
            this.textBox21.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(157, 25);
            this.textBox21.TabIndex = 46;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(338, 75);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(157, 25);
            this.textBox20.TabIndex = 45;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(173, 75);
            this.textBox19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(157, 25);
            this.textBox19.TabIndex = 44;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label17.Location = new System.Drawing.Point(59, 103);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 20);
            this.label17.TabIndex = 43;
            this.label17.Text = "CITY";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(8, 75);
            this.textBox18.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(157, 25);
            this.textBox18.TabIndex = 42;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label16.Location = new System.Drawing.Point(460, 52);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 20);
            this.label16.TabIndex = 41;
            this.label16.Text = "DISTRICT";
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(335, 24);
            this.textBox17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(322, 25);
            this.textBox17.TabIndex = 40;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label15.Location = new System.Drawing.Point(210, 52);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 20);
            this.label15.TabIndex = 39;
            this.label15.Text = "BARANGAY";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(173, 24);
            this.textBox16.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(157, 25);
            this.textBox16.TabIndex = 38;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label14.Location = new System.Drawing.Point(26, 52);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(117, 20);
            this.label14.TabIndex = 37;
            this.label14.Text = "NUMBER,STREET";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(8, 24);
            this.textBox15.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(157, 25);
            this.textBox15.TabIndex = 37;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label13.Location = new System.Drawing.Point(4, 1);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(126, 20);
            this.label13.TabIndex = 37;
            this.label13.Text = " MAILING ADDRESS:";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox23);
            this.panel4.Controls.Add(this.textBox22);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Location = new System.Drawing.Point(50, 488);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(680, 61);
            this.panel4.TabIndex = 28;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(341, 8);
            this.textBox23.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(316, 25);
            this.textBox23.TabIndex = 52;
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(8, 8);
            this.textBox22.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(322, 25);
            this.textBox22.TabIndex = 50;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label21.Location = new System.Drawing.Point(110, 36);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(116, 20);
            this.label21.TabIndex = 50;
            this.label21.Text = "MOTHER\'S NAME:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label22.Location = new System.Drawing.Point(440, 36);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 20);
            this.label22.TabIndex = 51;
            this.label22.Text = "FATHER\'S NAME:";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.radioButton6);
            this.panel5.Controls.Add(this.radioButton7);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Location = new System.Drawing.Point(50, 556);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(96, 181);
            this.panel5.TabIndex = 29;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.BackColor = System.Drawing.Color.Transparent;
            this.radioButton6.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton6.Location = new System.Drawing.Point(8, 58);
            this.radioButton6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(76, 24);
            this.radioButton6.TabIndex = 52;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "FEMALE";
            this.radioButton6.UseVisualStyleBackColor = false;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.BackColor = System.Drawing.Color.Transparent;
            this.radioButton7.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton7.Location = new System.Drawing.Point(9, 28);
            this.radioButton7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(60, 24);
            this.radioButton7.TabIndex = 51;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "MALE";
            this.radioButton7.UseVisualStyleBackColor = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label23.Location = new System.Drawing.Point(15, 5);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 20);
            this.label23.TabIndex = 50;
            this.label23.Text = "GENDER:";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.radioButton11);
            this.panel6.Controls.Add(this.radioButton10);
            this.panel6.Controls.Add(this.radioButton9);
            this.panel6.Controls.Add(this.radioButton8);
            this.panel6.Controls.Add(this.label24);
            this.panel6.Location = new System.Drawing.Point(152, 556);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(115, 181);
            this.panel6.TabIndex = 30;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.BackColor = System.Drawing.Color.Transparent;
            this.radioButton11.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton11.Location = new System.Drawing.Point(10, 116);
            this.radioButton11.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(101, 24);
            this.radioButton11.TabIndex = 56;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "SEPERATED";
            this.radioButton11.UseVisualStyleBackColor = false;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.BackColor = System.Drawing.Color.Transparent;
            this.radioButton10.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton10.Location = new System.Drawing.Point(10, 56);
            this.radioButton10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(83, 24);
            this.radioButton10.TabIndex = 55;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "MARRIED";
            this.radioButton10.UseVisualStyleBackColor = false;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.BackColor = System.Drawing.Color.Transparent;
            this.radioButton9.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton9.Location = new System.Drawing.Point(10, 86);
            this.radioButton9.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(88, 24);
            this.radioButton9.TabIndex = 54;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "WIDOWER";
            this.radioButton9.UseVisualStyleBackColor = false;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.BackColor = System.Drawing.Color.Transparent;
            this.radioButton8.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton8.Location = new System.Drawing.Point(10, 28);
            this.radioButton8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(72, 24);
            this.radioButton8.TabIndex = 53;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "SINGLE";
            this.radioButton8.UseVisualStyleBackColor = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label24.Location = new System.Drawing.Point(8, 5);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(94, 20);
            this.label24.TabIndex = 53;
            this.label24.Text = "CIVIL STATUS:";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label30);
            this.panel7.Controls.Add(this.label29);
            this.panel7.Controls.Add(this.label28);
            this.panel7.Controls.Add(this.label27);
            this.panel7.Controls.Add(this.label26);
            this.panel7.Controls.Add(this.textBox28);
            this.panel7.Controls.Add(this.textBox27);
            this.panel7.Controls.Add(this.textBox26);
            this.panel7.Controls.Add(this.textBox25);
            this.panel7.Controls.Add(this.textBox24);
            this.panel7.Controls.Add(this.label25);
            this.panel7.Location = new System.Drawing.Point(273, 556);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(457, 181);
            this.panel7.TabIndex = 31;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label30.Location = new System.Drawing.Point(22, 155);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(57, 20);
            this.label30.TabIndex = 66;
            this.label30.Text = "OTHER:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label29.Location = new System.Drawing.Point(43, 124);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(35, 20);
            this.label29.TabIndex = 65;
            this.label29.Text = "FAX:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label28.Location = new System.Drawing.Point(27, 93);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(52, 20);
            this.label28.TabIndex = 64;
            this.label28.Text = "E-MAIL:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label27.Location = new System.Drawing.Point(20, 62);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(59, 20);
            this.label27.TabIndex = 63;
            this.label27.Text = "MOBILE:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label26.Location = new System.Drawing.Point(43, 32);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(36, 20);
            this.label26.TabIndex = 50;
            this.label26.Text = "TEL:";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(98, 150);
            this.textBox28.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(229, 25);
            this.textBox28.TabIndex = 62;
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(98, 119);
            this.textBox27.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(229, 25);
            this.textBox27.TabIndex = 61;
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(98, 88);
            this.textBox26.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(229, 25);
            this.textBox26.TabIndex = 60;
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(98, 57);
            this.textBox25.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(229, 25);
            this.textBox25.TabIndex = 59;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(98, 26);
            this.textBox24.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(229, 25);
            this.textBox24.TabIndex = 58;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label25.Location = new System.Drawing.Point(60, 5);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(131, 20);
            this.label25.TabIndex = 57;
            this.label25.Text = "CONTACT NUMBER:";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.Controls.Add(this.textBox29);
            this.panel8.Controls.Add(this.radioButton17);
            this.panel8.Controls.Add(this.radioButton15);
            this.panel8.Controls.Add(this.radioButton14);
            this.panel8.Controls.Add(this.radioButton13);
            this.panel8.Controls.Add(this.radioButton12);
            this.panel8.Controls.Add(this.label31);
            this.panel8.Controls.Add(this.radioButton16);
            this.panel8.Location = new System.Drawing.Point(737, 62);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(196, 185);
            this.panel8.TabIndex = 32;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(87, 150);
            this.textBox29.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(101, 25);
            this.textBox29.TabIndex = 33;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.BackColor = System.Drawing.Color.Transparent;
            this.radioButton17.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton17.Location = new System.Drawing.Point(7, 151);
            this.radioButton17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(83, 24);
            this.radioButton17.TabIndex = 37;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "OTHERS:";
            this.radioButton17.UseVisualStyleBackColor = false;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.BackColor = System.Drawing.Color.Transparent;
            this.radioButton15.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton15.Location = new System.Drawing.Point(7, 108);
            this.radioButton15.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(126, 24);
            this.radioButton15.TabIndex = 35;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "COLLEGE LEVEL";
            this.radioButton15.UseVisualStyleBackColor = false;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.BackColor = System.Drawing.Color.Transparent;
            this.radioButton14.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton14.Location = new System.Drawing.Point(7, 89);
            this.radioButton14.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(131, 24);
            this.radioButton14.TabIndex = 34;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "TVET GRADUATE";
            this.radioButton14.UseVisualStyleBackColor = false;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.BackColor = System.Drawing.Color.Transparent;
            this.radioButton13.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton13.Location = new System.Drawing.Point(7, 68);
            this.radioButton13.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(182, 24);
            this.radioButton13.TabIndex = 33;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "HIGHSCHOOL GRADUATE";
            this.radioButton13.UseVisualStyleBackColor = false;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.BackColor = System.Drawing.Color.Transparent;
            this.radioButton12.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton12.Location = new System.Drawing.Point(7, 47);
            this.radioButton12.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(181, 24);
            this.radioButton12.TabIndex = 32;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "ELEMENTARY GRADUATE";
            this.radioButton12.UseVisualStyleBackColor = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label31.Location = new System.Drawing.Point(16, 5);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(144, 40);
            this.label31.TabIndex = 32;
            this.label31.Text = "HIGHEST EDUCATION \r\nATTAINMENT:";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.BackColor = System.Drawing.Color.Transparent;
            this.radioButton16.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton16.Location = new System.Drawing.Point(7, 128);
            this.radioButton16.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(124, 24);
            this.radioButton16.TabIndex = 36;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "COLLEGE GRAD";
            this.radioButton16.UseVisualStyleBackColor = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.Controls.Add(this.textBox11);
            this.panel9.Controls.Add(this.label1);
            this.panel9.Controls.Add(this.label2);
            this.panel9.Controls.Add(this.textBox2);
            this.panel9.Controls.Add(this.textBox10);
            this.panel9.Controls.Add(this.textBox8);
            this.panel9.Controls.Add(this.textBox9);
            this.panel9.Controls.Add(this.label3);
            this.panel9.Controls.Add(this.label7);
            this.panel9.Controls.Add(this.label4);
            this.panel9.Controls.Add(this.label5);
            this.panel9.Location = new System.Drawing.Point(50, 62);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(680, 92);
            this.panel9.TabIndex = 33;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.radioButton18);
            this.panel10.Controls.Add(this.radioButton19);
            this.panel10.Controls.Add(this.radioButton20);
            this.panel10.Controls.Add(this.radioButton21);
            this.panel10.Controls.Add(this.radioButton22);
            this.panel10.Controls.Add(this.radioButton23);
            this.panel10.Controls.Add(this.label32);
            this.panel10.Location = new System.Drawing.Point(939, 62);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(185, 185);
            this.panel10.TabIndex = 34;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label32.Location = new System.Drawing.Point(16, 2);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(150, 20);
            this.label32.TabIndex = 38;
            this.label32.Text = "EMPLOYMENT STATUS";
            this.label32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.BackColor = System.Drawing.Color.Transparent;
            this.radioButton18.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton18.Location = new System.Drawing.Point(20, 151);
            this.radioButton18.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(56, 24);
            this.radioButton18.TabIndex = 44;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "OFW";
            this.radioButton18.UseVisualStyleBackColor = false;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.BackColor = System.Drawing.Color.Transparent;
            this.radioButton19.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton19.Location = new System.Drawing.Point(20, 108);
            this.radioButton19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(105, 24);
            this.radioButton19.TabIndex = 42;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "PERMANENT";
            this.radioButton19.UseVisualStyleBackColor = false;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.BackColor = System.Drawing.Color.Transparent;
            this.radioButton20.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton20.Location = new System.Drawing.Point(20, 89);
            this.radioButton20.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(123, 24);
            this.radioButton20.TabIndex = 41;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "PROBATIONARY";
            this.radioButton20.UseVisualStyleBackColor = false;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.BackColor = System.Drawing.Color.Transparent;
            this.radioButton21.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton21.Location = new System.Drawing.Point(20, 68);
            this.radioButton21.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(99, 24);
            this.radioButton21.TabIndex = 40;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "JOB ORDER";
            this.radioButton21.UseVisualStyleBackColor = false;
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.BackColor = System.Drawing.Color.Transparent;
            this.radioButton22.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton22.Location = new System.Drawing.Point(20, 47);
            this.radioButton22.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(74, 24);
            this.radioButton22.TabIndex = 39;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "CASUAL";
            this.radioButton22.UseVisualStyleBackColor = false;
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.BackColor = System.Drawing.Color.Transparent;
            this.radioButton23.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.radioButton23.Location = new System.Drawing.Point(20, 128);
            this.radioButton23.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(130, 24);
            this.radioButton23.TabIndex = 43;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "SELF-EMPLOYED";
            this.radioButton23.UseVisualStyleBackColor = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label33.Location = new System.Drawing.Point(4, 4);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(128, 20);
            this.label33.TabIndex = 45;
            this.label33.Text = "WORK EXPERIENCE";
            this.label33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox30.Location = new System.Drawing.Point(7, 77);
            this.textBox30.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(93, 25);
            this.textBox30.TabIndex = 38;
            // 
            // textBox31
            // 
            this.textBox31.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(7, 140);
            this.textBox31.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(93, 25);
            this.textBox31.TabIndex = 46;
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(7, 108);
            this.textBox32.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(93, 25);
            this.textBox32.TabIndex = 47;
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(111, 76);
            this.textBox35.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(85, 25);
            this.textBox35.TabIndex = 48;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(111, 139);
            this.textBox34.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(86, 25);
            this.textBox34.TabIndex = 49;
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(111, 107);
            this.textBox33.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(85, 25);
            this.textBox33.TabIndex = 50;
            // 
            // textBox38
            // 
            this.textBox38.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox38.Location = new System.Drawing.Point(207, 77);
            this.textBox38.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(65, 25);
            this.textBox38.TabIndex = 51;
            // 
            // textBox37
            // 
            this.textBox37.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox37.Location = new System.Drawing.Point(207, 139);
            this.textBox37.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(65, 25);
            this.textBox37.TabIndex = 52;
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(207, 108);
            this.textBox36.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(65, 25);
            this.textBox36.TabIndex = 53;
            // 
            // textBox41
            // 
            this.textBox41.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox41.Location = new System.Drawing.Point(280, 77);
            this.textBox41.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(65, 25);
            this.textBox41.TabIndex = 54;
            // 
            // textBox40
            // 
            this.textBox40.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox40.Location = new System.Drawing.Point(280, 139);
            this.textBox40.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(65, 25);
            this.textBox40.TabIndex = 55;
            // 
            // textBox39
            // 
            this.textBox39.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(280, 108);
            this.textBox39.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(65, 25);
            this.textBox39.TabIndex = 56;
            // 
            // textBox44
            // 
            this.textBox44.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(353, 77);
            this.textBox44.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(84, 25);
            this.textBox44.TabIndex = 57;
            // 
            // textBox43
            // 
            this.textBox43.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox43.Location = new System.Drawing.Point(353, 140);
            this.textBox43.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(85, 25);
            this.textBox43.TabIndex = 58;
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(353, 108);
            this.textBox42.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(84, 25);
            this.textBox42.TabIndex = 59;
            // 
            // textBox47
            // 
            this.textBox47.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox47.Location = new System.Drawing.Point(445, 76);
            this.textBox47.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(84, 25);
            this.textBox47.TabIndex = 60;
            // 
            // textBox46
            // 
            this.textBox46.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox46.Location = new System.Drawing.Point(445, 139);
            this.textBox46.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(85, 25);
            this.textBox46.TabIndex = 61;
            // 
            // textBox45
            // 
            this.textBox45.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(445, 107);
            this.textBox45.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(84, 25);
            this.textBox45.TabIndex = 62;
            // 
            // textBox50
            // 
            this.textBox50.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox50.Location = new System.Drawing.Point(537, 76);
            this.textBox50.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(84, 25);
            this.textBox50.TabIndex = 63;
            // 
            // textBox49
            // 
            this.textBox49.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox49.Location = new System.Drawing.Point(537, 139);
            this.textBox49.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(85, 25);
            this.textBox49.TabIndex = 64;
            // 
            // textBox48
            // 
            this.textBox48.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox48.Location = new System.Drawing.Point(537, 107);
            this.textBox48.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(84, 25);
            this.textBox48.TabIndex = 65;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label34.Location = new System.Drawing.Point(16, 34);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(73, 40);
            this.label34.TabIndex = 66;
            this.label34.Text = "COMPANY \r\nNAME";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.label40);
            this.panel11.Controls.Add(this.label41);
            this.panel11.Controls.Add(this.label42);
            this.panel11.Controls.Add(this.label43);
            this.panel11.Controls.Add(this.label44);
            this.panel11.Controls.Add(this.textBox51);
            this.panel11.Controls.Add(this.textBox52);
            this.panel11.Controls.Add(this.textBox53);
            this.panel11.Controls.Add(this.textBox54);
            this.panel11.Controls.Add(this.textBox55);
            this.panel11.Controls.Add(this.textBox56);
            this.panel11.Controls.Add(this.textBox57);
            this.panel11.Controls.Add(this.textBox58);
            this.panel11.Controls.Add(this.textBox59);
            this.panel11.Controls.Add(this.textBox60);
            this.panel11.Controls.Add(this.textBox61);
            this.panel11.Controls.Add(this.textBox62);
            this.panel11.Controls.Add(this.textBox63);
            this.panel11.Controls.Add(this.textBox64);
            this.panel11.Controls.Add(this.textBox65);
            this.panel11.Controls.Add(this.textBox66);
            this.panel11.Controls.Add(this.textBox67);
            this.panel11.Controls.Add(this.textBox68);
            this.panel11.Controls.Add(this.label39);
            this.panel11.Controls.Add(this.label38);
            this.panel11.Controls.Add(this.label37);
            this.panel11.Controls.Add(this.label36);
            this.panel11.Controls.Add(this.label35);
            this.panel11.Controls.Add(this.label34);
            this.panel11.Controls.Add(this.textBox48);
            this.panel11.Controls.Add(this.textBox49);
            this.panel11.Controls.Add(this.textBox50);
            this.panel11.Controls.Add(this.textBox45);
            this.panel11.Controls.Add(this.textBox46);
            this.panel11.Controls.Add(this.textBox47);
            this.panel11.Controls.Add(this.textBox42);
            this.panel11.Controls.Add(this.textBox43);
            this.panel11.Controls.Add(this.textBox44);
            this.panel11.Controls.Add(this.textBox39);
            this.panel11.Controls.Add(this.textBox40);
            this.panel11.Controls.Add(this.textBox41);
            this.panel11.Controls.Add(this.textBox36);
            this.panel11.Controls.Add(this.textBox37);
            this.panel11.Controls.Add(this.textBox38);
            this.panel11.Controls.Add(this.textBox33);
            this.panel11.Controls.Add(this.textBox34);
            this.panel11.Controls.Add(this.textBox35);
            this.panel11.Controls.Add(this.textBox32);
            this.panel11.Controls.Add(this.textBox31);
            this.panel11.Controls.Add(this.textBox30);
            this.panel11.Controls.Add(this.label33);
            this.panel11.Location = new System.Drawing.Point(737, 253);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(637, 484);
            this.panel11.TabIndex = 35;
            this.panel11.Paint += new System.Windows.Forms.PaintEventHandler(this.panel11_Paint);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.Transparent;
            this.label35.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label35.Location = new System.Drawing.Point(119, 44);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(69, 20);
            this.label35.TabIndex = 67;
            this.label35.Text = "POSITION";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label36.Location = new System.Drawing.Point(240, 34);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(72, 40);
            this.label36.TabIndex = 68;
            this.label36.Text = "INCLUSIVE\r\nDATES\r\n";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label37.Location = new System.Drawing.Point(360, 34);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(71, 40);
            this.label37.TabIndex = 69;
            this.label37.Text = "MONTHLY\r\nSALARY";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label38.Location = new System.Drawing.Point(439, 34);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(100, 40);
            this.label38.TabIndex = 70;
            this.label38.Text = "STATUS\r\nAPPOINTMENT\r\n";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label39.Location = new System.Drawing.Point(547, 33);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(69, 40);
            this.label39.TabIndex = 71;
            this.label39.Text = "NO. YRS \r\nWORKING";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox51
            // 
            this.textBox51.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox51.Location = new System.Drawing.Point(529, 247);
            this.textBox51.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(95, 25);
            this.textBox51.TabIndex = 89;
            // 
            // textBox52
            // 
            this.textBox52.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox52.Location = new System.Drawing.Point(529, 279);
            this.textBox52.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(96, 25);
            this.textBox52.TabIndex = 88;
            // 
            // textBox53
            // 
            this.textBox53.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox53.Location = new System.Drawing.Point(529, 216);
            this.textBox53.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(95, 25);
            this.textBox53.TabIndex = 87;
            // 
            // textBox54
            // 
            this.textBox54.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox54.Location = new System.Drawing.Point(397, 247);
            this.textBox54.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(124, 25);
            this.textBox54.TabIndex = 86;
            // 
            // textBox55
            // 
            this.textBox55.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox55.Location = new System.Drawing.Point(397, 279);
            this.textBox55.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(124, 25);
            this.textBox55.TabIndex = 85;
            // 
            // textBox56
            // 
            this.textBox56.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox56.Location = new System.Drawing.Point(397, 216);
            this.textBox56.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(124, 25);
            this.textBox56.TabIndex = 84;
            // 
            // textBox57
            // 
            this.textBox57.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox57.Location = new System.Drawing.Point(313, 248);
            this.textBox57.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(76, 25);
            this.textBox57.TabIndex = 83;
            // 
            // textBox58
            // 
            this.textBox58.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox58.Location = new System.Drawing.Point(313, 279);
            this.textBox58.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(76, 25);
            this.textBox58.TabIndex = 82;
            // 
            // textBox59
            // 
            this.textBox59.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox59.Location = new System.Drawing.Point(313, 217);
            this.textBox59.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(76, 25);
            this.textBox59.TabIndex = 81;
            // 
            // textBox60
            // 
            this.textBox60.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox60.Location = new System.Drawing.Point(229, 249);
            this.textBox60.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(76, 25);
            this.textBox60.TabIndex = 80;
            // 
            // textBox61
            // 
            this.textBox61.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox61.Location = new System.Drawing.Point(229, 280);
            this.textBox61.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(76, 25);
            this.textBox61.TabIndex = 79;
            // 
            // textBox62
            // 
            this.textBox62.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox62.Location = new System.Drawing.Point(229, 218);
            this.textBox62.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(76, 25);
            this.textBox62.TabIndex = 78;
            // 
            // textBox63
            // 
            this.textBox63.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox63.Location = new System.Drawing.Point(123, 248);
            this.textBox63.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(96, 25);
            this.textBox63.TabIndex = 77;
            // 
            // textBox64
            // 
            this.textBox64.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox64.Location = new System.Drawing.Point(123, 280);
            this.textBox64.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(97, 25);
            this.textBox64.TabIndex = 76;
            // 
            // textBox65
            // 
            this.textBox65.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox65.Location = new System.Drawing.Point(123, 217);
            this.textBox65.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(96, 25);
            this.textBox65.TabIndex = 75;
            // 
            // textBox66
            // 
            this.textBox66.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox66.Location = new System.Drawing.Point(11, 248);
            this.textBox66.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(104, 25);
            this.textBox66.TabIndex = 74;
            // 
            // textBox67
            // 
            this.textBox67.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox67.Location = new System.Drawing.Point(11, 280);
            this.textBox67.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(104, 25);
            this.textBox67.TabIndex = 73;
            // 
            // textBox68
            // 
            this.textBox68.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox68.Location = new System.Drawing.Point(11, 217);
            this.textBox68.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(104, 25);
            this.textBox68.TabIndex = 72;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label40.Location = new System.Drawing.Point(524, 175);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(100, 40);
            this.label40.TabIndex = 94;
            this.label40.Text = "STATUS\r\nAPPOINTMENT\r\n";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label41.Location = new System.Drawing.Point(420, 173);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(71, 40);
            this.label41.TabIndex = 93;
            this.label41.Text = "MONTHLY\r\nSALARY";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label42.Location = new System.Drawing.Point(273, 174);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(72, 40);
            this.label42.TabIndex = 92;
            this.label42.Text = "INCLUSIVE\r\nDATES\r\n";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label43.Location = new System.Drawing.Point(137, 194);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(69, 20);
            this.label43.TabIndex = 91;
            this.label43.Text = "POSITION";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.Font = new System.Drawing.Font("Arial Narrow", 11.25F);
            this.label44.Location = new System.Drawing.Point(27, 175);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(73, 40);
            this.label44.TabIndex = 90;
            this.label44.Text = "COMPANY \r\nNAME";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // User_RegisteredPeopleModuleRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1386, 788);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel9);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.Name = "User_RegisteredPeopleModuleRegister";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User_RegisteredModuleRegister";
            this.Load += new System.EventHandler(this.User_RegisteredPeopleModuleRegister_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
    }
}