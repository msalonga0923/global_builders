﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PHqctx
{
    public partial class User_RegisteredPeopleModuleRegister : Form
    {
        public User_RegisteredPeopleModuleRegister()
        {
            InitializeComponent();
        }

        private void User_RegisteredPeopleModuleRegister_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel1.Width, panel1.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel2.Width, panel2.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel3.Width, panel3.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel4.Width, panel4.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel5.Width, panel5.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel6.Width, panel6.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel7.Width, panel7.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel8.Width, panel8.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel9.Width, panel9.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel10_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel10.Width, panel10.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

        private void panel11_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics graphics = e.Graphics;
            System.Drawing.Rectangle gradient_rectangle = new System.Drawing.Rectangle(0, 0, panel11.Width, panel11.Height);
            System.Drawing.Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(gradient_rectangle, System.Drawing.Color.FromArgb(255, 0, 0), System.Drawing.Color.FromArgb(48, 145, 255), 65f);
            graphics.FillRectangle(b, gradient_rectangle);
        }

    }
}
